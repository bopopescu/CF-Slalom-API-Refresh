const dev = require('./templates/templates.dev.json');
const test = require('./templates/templates.test.json');
const prod = require('./templates/templates.prod.json');

module.exports = {
  "dev": dev,
  "test": test,
  "prod": prod
}