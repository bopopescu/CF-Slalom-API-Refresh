#CF Domo-AWS Lambda Connector

This project entails a Data loader to Domo from several sources using AWS Lambda functions and based on the serverless framework.

# First Time Deploy
npm install
npm install mysql
npm run clean-dev (or stage desired)
npm run deploy-dev (or stage desired)
